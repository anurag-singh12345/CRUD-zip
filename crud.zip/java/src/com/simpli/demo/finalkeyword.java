package com.simpli.demo;

public class finalkeyword {
	public static void main(String[]  args) {
		A a1=new A();
	}

}
class A{
	final int x=100;
	final public void m() {
		System.out.println("Hi");
	}
}
class B extends A{
	public void m() {
		System.out.println("Hi");
		
	}
}