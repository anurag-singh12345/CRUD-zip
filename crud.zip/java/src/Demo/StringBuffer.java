package Demo;

public class StringBuffer {

	public static void main(String[] args) {
		StringBuffer s=new StringBuffer("Hello");
		System.out.println(s);
		s.append("World");
		System.out.println(s);
		

	}

}
