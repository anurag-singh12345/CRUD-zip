import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class FileCRUDOperations {

    public static void main(String[] args) {
        
        String filePath = "sample.txt";

       
        createFile(filePath);

  
        readFile(filePath);

   
        updateFile(filePath);

       
        readFile(filePath);

       
        deleteFile(filePath);
    }

    private static void createFile(String filePath) {
        try {
            File file = new File(filePath);

           
            if (file.createNewFile()) {
                System.out.println("File created: " + file.getName());
            } else {
                System.out.println("File already exists.");
            }
        } catch (IOException e) {
            System.out.println("An error occurred while creating the file.");
            e.printStackTrace();
        }
    }

    private static void readFile(String filePath) {
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            System.out.println("\nReading from the file:");
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException e) {
            System.out.println("An error occurred while reading from the file.");
            e.printStackTrace();
        }
    }

    private static void updateFile(String filePath) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath, true))) {
            System.out.println("\nUpdating the file:");

            // Append new content to the file
            writer.newLine();
            writer.write("Additional line added.");
            System.out.println("File updated successfully.");
        } catch (IOException e) {
            System.out.println("An error occurred while updating the file.");
            e.printStackTrace();
        }
    }

    private static void deleteFile(String filePath) {
        File file = new File(filePath);

        if (file.delete()) {
            System.out.println("\nFile deleted: " + file.getName());
        } else {
            System.out.println("\nFailed to delete the file. File may not exist.");
        }
    }
}
