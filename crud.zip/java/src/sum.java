
public class sum
{
	static int add(int x,int y) 
	{
		return x+y;
	}
	static double add(double x,double y) {
		return x+y;
	}
}	
public class R{
	

	public static void main(String[] args)
	{
		System.out.println(sum.add(12, 11));
		System.out.println(sum.add(12.3, 11.6));
		
		
		
	}

}


