public class ArraysExample {

    public static void main(String[] args) {
       
        int[] oneDimensionalArray = {1, 2, 3, 4, 5};

        System.out.println("One-dimensional Array:");
        displayArray(oneDimensionalArray);

       
        int[][] twoDimensionalArray = {
                {1, 2, 3},
                {4, 5, 6},
                {7, 8, 9}
        };

        System.out.println("\nTwo-dimensional Array:");
        displayArray(twoDimensionalArray);
    }

   
    private static void displayArray(int[] array) {
        for (int element : array) {
            System.out.print(element + " ");
        }
        System.out.println();
    }

   
    private static void displayArray(int[][] array) {
        for (int[] row : array) {
            for (int element : row) {
                System.out.print(element + " ");
            }
            System.out.println();
        }
    }
}